//
//  ViewController.m
//  Textfiled
//
//  Created by ljj on 16/7/2.
//  Copyright © 2016年 ljj. All rights reserved.
//

#import "ViewController.h"
#import "TextFieldFrame.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    TextFieldFrame *text = [[TextFieldFrame alloc]initWithFrame:CGRectMake(100, 100, 100, 30)];
    text.needNum = 800;
    text.placeholder = @"dsfsdfsd";
    text.backgroundColor = [UIColor greenColor];
    [self.view addSubview:text];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
