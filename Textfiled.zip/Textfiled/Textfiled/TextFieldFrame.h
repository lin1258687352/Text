//
//  TextFieldFrame.h
//  Textfiled
//
//  Created by ljj on 16/7/2.
//  Copyright © 2016年 ljj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFieldFrame : UITextField<UITextFieldDelegate>

@property (nonatomic, copy)NSString *ljjPlac;

@property (nonatomic, assign) NSInteger needNum;

@property (nonatomic, assign) NSInteger point;

@end
