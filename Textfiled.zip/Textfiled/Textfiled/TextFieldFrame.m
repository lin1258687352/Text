//
//  TextFieldFrame.m
//  Textfiled
//
//  Created by ljj on 16/7/2.
//  Copyright © 2016年 ljj. All rights reserved.
//

#import "TextFieldFrame.h"

@implementation TextFieldFrame

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.delegate = self;
        [self setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
        
        
    }
    return self;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *temp;
    temp = [textField.text stringByReplacingCharactersInRange:range withString:string];
        //判断是不是数字
        for (int i = 0; i < temp.length; i ++) {
            
            char num = [[temp substringWithRange:NSMakeRange(i, 1)] characterAtIndex:0];
            
            if ((num > 47 && num < 58) || num == 46) {
            }else{
                NSLog(@"%@", temp);
                return NO;
            }
        }
        int a = 0;
        //大于300
        if ([temp integerValue] > _needNum) {
            textField.text = [NSString stringWithFormat:@"%ld", _needNum];
            if ([temp intValue] > _needNum) {
            }
            return NO;
            
        }else{
            //是否有小数点
            if ([textField.text containsString:@"."]) {
                NSRange range = [textField.text rangeOfString:@"."];
                NSString *str1 = [temp substringToIndex:range.location];
                NSString *str2 = [textField.text substringFromIndex:range.location + 1];
                NSString *str3 = [str2 substringWithRange:NSMakeRange(0, str2.length)];
                
                if ([str1 intValue] >= _needNum) {
                    textField.text = [NSString stringWithFormat:@"%ld", _needNum];
                    return NO;
                }else{
                    if (str3.length > _point - 1) {
                        a = 1;
                        str3 = [str3 substringToIndex:_point - 1];
                    }else{
                        if ([temp integerValue] > _needNum) {

                            return NO;
                            
                        }else{
                            textField.text = [NSString stringWithFormat:@"%@.%@", str1, str3];
                        }
                        
                    }
                    if(range.location + 1 > temp.length){
                    }else{
                        NSLog(@"%@======", temp);
                        NSString *str4 = [temp substringFromIndex:range.location + 1];
                        if (str4.length == 3) {
                            return NO;
                        }
                        
                    }
                }
            }
            else{
                if(temp.length > 3){
                    textField.text = [NSString stringWithFormat:@"%ld", _needNum];
                    return NO;
                }
            }
        }
        
//    }
    return YES;

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
